import React from "react";
import { ChevronRight, Shield } from "lucide-react";
import { motion } from "motion/react";

// Pointed-topped hexagon logo with Curcumin synthesis chemical bonds
const HexagonLogo: React.FC = () => {
  return (
    <svg
      id="curcumin-brand-logo"
      className="w-12 h-12 text-[#bf801d]"
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Golden Hexagon Outline */}
      <path
        d="M50 8 L86 29 L86 71 L50 92 L14 71 L14 29 Z"
        stroke="currentColor"
        strokeWidth="4"
        strokeLinejoin="round"
        className="text-[#bf801d]"
      />
      {/* Synthesis / Chemical Bonds inside */}
      <path
        d="M32 35 L50 65 L68 40"
        stroke="currentColor"
        strokeWidth="3.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="text-[#bf801d]"
      />
      {/* Connected chemical nodes */}
      <circle cx="32" cy="35" r="5" fill="#ffffff" stroke="currentColor" strokeWidth="2" />
      <circle cx="50" cy="65" r="5" fill="#ffffff" stroke="currentColor" strokeWidth="2" />
      <circle cx="68" cy="40" r="5" fill="#ffffff" stroke="currentColor" strokeWidth="2" />
    </svg>
  );
};

// Custom premium Shield with the inner purity percentage
interface ShieldIconProps {
  percentage: string;
}

const ShieldIcon: React.FC<ShieldIconProps> = ({ percentage }) => {
  return (
    <div className="relative flex items-center justify-center w-16 h-18 text-[#bf801d]" id={`shield-${percentage}`}>
      {/* Custom elegant SVG Shield */}
      <svg
        className="w-full h-full"
        viewBox="0 0 100 110"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M50 100C50 100 85 82 85 50V20L50 8L15 20V50C15 82 50 100 50 100Z"
          stroke="currentColor"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="text-[#bf801d]"
        />
      </svg>
      {/* Centered Percentage Value */}
      <span className="absolute top-[42%] left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-sm md:text-base font-semibold tracking-tighter text-[#bf801d] font-sans">
        {percentage}
      </span>
    </div>
  );
};

export default function App() {
  const purityMetrics = [
    { value: "95%", label: "95% Purity" },
    { value: "98%", label: "98% Purity" },
    { value: "99%", label: "99% Purity" },
    { value: "99.5%", label: "99.5% Purity" },
  ];

  return (
    <div 
      id="hero-root-container" 
      className="min-h-screen w-full bg-[#f4ebd9] text-[#1a1105] font-sans flex flex-col justify-start relative overflow-hidden select-none"
    >
      {/* Organic texture and warm lighting effects matching the uploaded image */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        {/* Subtle noise pattern overlay to give natural paper/linen texture */}
        <div className="absolute inset-0 opacity-[0.03] mix-blend-overlay bg-[radial-gradient(#111_1px,transparent_1px)] [background-size:16px_16px]" />
        
        {/* Warm sunlight beam casting softly from top-right to bottom-left */}
        <div className="absolute top-0 right-0 w-[80%] h-[120%] bg-gradient-to-bl from-white/40 via-amber-100/10 to-transparent rotate-12 transform origin-top-right blur-[80px]" />
        
        {/* Soft natural shadows in the corners */}
        <div className="absolute bottom-0 left-0 w-[40%] h-[40%] bg-gradient-to-tr from-stone-900/[0.03] to-transparent blur-3xl" />
      </div>

      {/* High-fidelity responsive top-down visual elements on the right half, matching the uploaded image perfectly */}
      <div id="ambient-right-visuals" className="absolute top-1/2 -translate-y-1/2 right-[-5%] xl:right-[1%] w-[600px] h-[600px] hidden lg:flex items-center justify-center pointer-events-none select-none z-0 transform scale-90 xl:scale-100 transition-transform duration-500">
        
        {/* Golden connecting arcs representing synthesis/bonds across the composition */}
        <svg className="absolute inset-0 w-full h-full text-[#bf801d]/60" viewBox="0 0 600 600" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Main big elegant curved loop */}
          <path 
            d="M 120 480 A 240 240 0 1 1 480 100" 
            stroke="currentColor" 
            strokeWidth="1.5" 
            strokeDasharray="4 4" 
            className="opacity-40"
          />
          <path 
            d="M 120 480 A 240 240 0 1 1 480 100" 
            stroke="currentColor" 
            strokeWidth="1.5" 
          />
          {/* Dots on the arc */}
          <circle cx="80" cy="300" r="6" fill="#bf801d" />
          <circle cx="480" cy="100" r="8" fill="#bf801d" />
          {/* Connecting line to glass area */}
          <line x1="480" y1="100" x2="520" y2="120" stroke="currentColor" strokeWidth="1" />
        </svg>

        {/* Large Speckled Ceramic Plate */}
        <div className="absolute w-[460px] h-[460px] rounded-full bg-[#ebdcb9] border border-white/40 shadow-[0_24px_70px_rgba(92,72,48,0.18)] flex items-center justify-center transform rotate-12 overflow-hidden">
          {/* Speckled textures and shadow inner rim */}
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_40%,rgba(0,0,0,0.06)_100%)]" />
          <div className="absolute top-6 left-12 w-[150%] h-[150%] opacity-[0.06] bg-[radial-gradient(#5a4220_1px,transparent_1.5px)] [background-size:12px_12px]" />
          
          {/* Plate inner elegant ridge ring */}
          <div className="w-[360px] h-[360px] rounded-full border border-stone-800/5 shadow-inner bg-gradient-to-tr from-white/10 to-transparent flex items-center justify-center">
            
            {/* The Clear Glass Curcumin Powder Cup / Plate in Center */}
            <div className="w-[250px] h-[250px] rounded-full bg-white/5 backdrop-blur-[2px] border border-white/40 shadow-[0_12px_36px_rgba(0,0,0,0.12)] flex items-center justify-center p-2 relative">
              
              {/* Concentric rings representing highly textured Curcumin powder pile */}
              <div className="w-full h-full rounded-full bg-gradient-to-br from-[#e8901a] via-[#bf7011] to-[#9c4a03] relative flex items-center justify-center overflow-hidden shadow-inner">
                {/* 3D highlights for organic powder look */}
                <div className="absolute inset-x-0 top-0 h-1/2 bg-gradient-to-b from-white/20 to-transparent" />
                
                {/* Meticulous Concentric Powder Ridgelines */}
                <div className="absolute w-[90%] h-[90%] rounded-full border border-[#f5b24c]/40 opacity-70" />
                <div className="absolute w-[75%] h-[75%] rounded-full border border-[#f5b24c]/40 opacity-85" />
                <div className="absolute w-[60%] h-[60%] rounded-full border border-black/10 shadow-[inset_0_2px_4px_rgba(255,255,255,0.2)] bg-[#cf7914]" />
                <div className="absolute w-[45%] h-[45%] rounded-full border border-[#f5b24c]/40 opacity-90" />
                <div className="absolute w-[30%] h-[30%] rounded-full border border-black/15 bg-[#bf6b11]" />
                
                {/* Micro-grains texture simulation */}
                <div className="absolute inset-0 opacity-[0.25] mix-blend-overlay bg-[radial-gradient(#fff_1.2px,transparent_1.2px)] [background-size:6px_6px]" />
                <div className="absolute inset-0 opacity-[0.15] mix-blend-multiply bg-[radial-gradient(#111_1.5px,transparent_1.5px)] [background-size:4px_4px]" />
              </div>

              {/* Glass Rim highlight reflections */}
              <div className="absolute inset-0 rounded-full border-2 border-white/60 pointer-events-none m-[-2px] opacity-80" />
              <div className="absolute top-[8%] left-[8%] w-[84%] h-[84%] rounded-full border border-white/20 pointer-events-none opacity-40" />
            </div>

          </div>
        </div>

        {/* Elegant Gold Metallic Spoon */}
        <div className="absolute top-[16%] right-[6%] transform rotate-[-42deg] drop-shadow-[5px_15px_12px_rgba(92,72,48,0.25)] flex flex-col items-center pointer-events-none">
          {/* Spoon Handle */}
          <div className="w-4 h-56 bg-gradient-to-r from-[#d99c3a] via-[#bf801d] to-[#9c6310] rounded-b-md relative">
            <div className="absolute inset-y-0 left-0.5 w-[2px] bg-white/20" />
            {/* Elegant handle ring end details */}
            <div className="absolute bottom-0 w-full h-4 bg-[#804e06] rounded-b-md" />
          </div>
          {/* Spoon Neck */}
          <div className="w-6 h-12 bg-gradient-to-r from-[#d99c3a] to-[#9c6310] border-y border-[#804e06]" />
          {/* Spoon Bowl with Curcumin Paste */}
          <div className="w-12 h-20 rounded-t-full rounded-b-3xl bg-gradient-to-br from-[#f2b350] via-[#c4811a] to-[#734204] relative flex items-center justify-center overflow-hidden">
            <div className="absolute inset-y-1 inset-x-2 rounded-t-full rounded-b-2xl bg-[#915609] brightness-75 flex items-center justify-center">
              {/* Highlight paste */}
              <div className="w-[80%] h-[80%] rounded-full bg-[#bf7315] blur-[2px] opacity-90" />
            </div>
            {/* Specular metallic highlight line */}
            <div className="absolute left-1 top-2 w-[2px] h-[70%] bg-white/45 rounded-full" />
          </div>
        </div>

        {/* Elite clear water glass elements on upper right */}
        <div className="absolute top-[5%] right-[-15px] transform scale-90 opacity-90">
          <div className="w-32 h-32 rounded-full border border-white/50 shadow-[0_12px_30px_rgba(0,0,0,0.08)] bg-white/10 backdrop-blur-[3px] p-1 flex items-center justify-center relative">
            <div className="w-[85%] h-[85%] rounded-full border border-white/35 bg-gradient-to-tr from-white/20 via-transparent to-transparent flex items-center justify-center">
              <div className="w-[70%] h-[70%] rounded-full border border-white/20 bg-white/5" />
            </div>
            {/* Water dynamic sheen */}
            <div className="absolute top-[15%] left-[20%] w-[3px] h-[30%] bg-white/50 rounded-full transform -rotate-12" />
            <div className="absolute bottom-[20%] right-[20%] w-[2px] h-[15%] bg-white/30 rounded-full" />
          </div>
        </div>

        {/* Scattered Curcumin small paste drops and particles on the plate or right around */}
        <div className="absolute bottom-[22%] left-[18%] w-5 h-5 rounded-full bg-[#c27613] shadow-[0_2px_4px_rgba(0,0,0,0.15)] filter blur-[0.5px]" />
        <div className="absolute bottom-[16%] left-[23%] w-4 h-4 rounded-full bg-[#aa6203] shadow-[0_2px_4px_rgba(0,0,0,0.15)] filter blur-[0.5px]" />
        <div className="absolute bottom-[28%] left-[21%] w-3 h-3 rounded-full bg-[#d08420] shadow-[0_1px_2px_rgba(0,0,0,0.12)]" />

        {/* Beautiful Draped White Linen Fabric mockup on bottom right corner */}
        <div className="absolute bottom-[-15px] right-[-60px] w-52 h-44 opacity-80 pointer-events-none transform rotate-[-12deg]">
          <svg className="w-full h-full text-white/50" viewBox="0 0 200 150" fill="currentColor">
            <path d="M 0 150 Q 50 110, 80 120 T 150 70 T 200 90 L 200 150 Z" />
            <path d="M 30 150 Q 80 100, 110 115 T 180 65 L 200 65 L 200 150 Z" className="text-white/20" />
            <path d="M 60 150 Q 110 95, 140 105 L 200 150 Z" className="text-white/30" />
          </svg>
        </div>

      </div>

      {/* Header / Navigation bar */}
      <header id="main-navigation-header" className="w-full px-8 md:px-16 lg:px-24 py-8 flex items-center justify-between z-10 relative">
        {/* Brand Logo & Title */}
        <div id="brand-logo-group" className="flex items-center space-x-4">
          <HexagonLogo />
          <div className="flex flex-col select-none leading-none">
            <span className="text-xl md:text-2xl font-bold tracking-[0.05em] text-[#1a1105]">
              CURCUMIN
            </span>
            <span className="text-[10px] md:text-xs font-semibold tracking-[0.38em] text-[#b0741a] mt-1 uppercase">
              SOLUTIONS
            </span>
          </div>
        </div>

        {/* Navigation Menu */}
        <nav id="navbar-menu-items" className="hidden md:flex items-center space-x-12 text-[15px] font-medium tracking-wide">
          <div className="flex flex-col items-center">
            <span className="text-[#b0741a] font-semibold cursor-pointer">Home</span>
            {/* Active Indication Bar exactly like screenshot */}
            <span className="w-10 h-[2px] bg-[#b0741a] mt-1.5" />
          </div>
          <a href="#about" className="text-[#3d3225] hover:text-[#b0741a] transition duration-200">
            About Us
          </a>
          <a href="#products" className="text-[#3d3225] hover:text-[#b0741a] transition duration-200">
            Products
          </a>
          <a href="#quality" className="text-[#3d3225] hover:text-[#b0741a] transition duration-200">
            Quality
          </a>
        </nav>

        {/* Mobile menu indicator placeholder */}
        <div className="md:hidden flex items-center space-x-2 text-xs text-[#524434] border border-[#d8ccb8] bg-[#fdfaf4]/40 rounded px-3 py-1 cursor-not-allowed">
          <span>● Options</span>
        </div>
      </header>

      {/* Main Hero Body */}
      <main id="hero-main-layout" className="flex-grow w-full px-8 md:px-16 lg:px-24 py-12 md:py-20 flex flex-col justify-center z-10 relative">
        <div className="max-w-[760px] text-left flex flex-col">
          
          {/* Subheading text */}
          <motion.p
            id="hero-subtitle-caps"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="text-[#b0741a] text-sm md:text-base font-semibold tracking-wide uppercase mb-3 selection:bg-[#b0741a]/30"
          >
            The Reliable Alternative to Chinese Curcumin
          </motion.p>

          {/* Main Headline */}
          <motion.h1
            id="hero-main-title"
            initial={{ opacity: 0, y: 25 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1, ease: "easeOut" }}
            className="font-serif text-[44px] sm:text-[56px] md:text-[68px] font-medium leading-[1.12] tracking-tight selection:bg-[#b0741a]/20 text-balance text-[#1a1105]"
          >
            India's First Synthetic <br />
            <span className="text-[#b0741a]">Manufacturer</span>
          </motion.h1>

          {/* Description Paragraph */}
          <motion.p
            id="hero-main-description"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
            className="text-[#493c2c] text-base md:text-lg font-sans leading-relaxed mt-6 mb-10 max-w-[560px] selection:bg-[#ebdcb9]"
          >
            Supplying food, pharma, cosmetic and nutraceutical industries with ISO-certified synthetic curcumin.
          </motion.p>

          {/* Grid of Purity Badges */}
          <motion.div
            id="purity-badges-row"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3, ease: "easeOut" }}
            className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-10 mr-auto w-full max-w-[620px]"
          >
            {purityMetrics.map((metric, i) => (
              <div
                key={i}
                id={`badge-card-${i}`}
                className="border border-[#e5d9c3] bg-[#fdfaf4]/70 hover:border-[#b0741a]/60 rounded-lg p-5 flex flex-col items-center justify-center text-center transition-all duration-300 group hover:shadow-[0_8px_24px_rgba(176,116,26,0.06)]"
              >
                <div className="transform group-hover:scale-105 transition-transform duration-300">
                  <ShieldIcon percentage={metric.value} />
                </div>
                <span className="text-xs md:text-sm font-sans font-medium text-[#493c2c] mt-4 tracking-wide group-hover:text-[#1a1105] transition-colors">
                  {metric.label}
                </span>
              </div>
            ))}
          </motion.div>

          {/* Action Buttons */}
          <motion.div
            id="cta-action-container"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4, ease: "easeOut" }}
            className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 sm:gap-6 mt-2 shadow-[none]"
          >
            {/* Primary Request Bulk Quote Button */}
            <button
              id="cta-btn-request-quote"
              className="px-6 md:px-8 py-3.5 md:py-4 bg-[#b0741a] hover:bg-[#965e0f] text-white rounded font-sans font-semibold text-xs md:text-sm tracking-widest uppercase transition-all duration-200 active:scale-95 flex items-center justify-center space-x-2 shadow-lg shadow-[#b0741a]/15 cursor-pointer"
            >
              <span>REQUEST BULK QUOTE</span>
              <ChevronRight size={16} strokeWidth={2.5} />
            </button>

            {/* Secondary Download Button */}
            <button
              id="cta-btn-download-specs"
              className="px-6 md:px-8 py-3.5 md:py-4 border border-[#b0741a] hover:bg-[#b0741a]/5 text-[#3d3225] hover:text-[#b0741a] rounded font-sans font-semibold text-xs md:text-sm tracking-widest uppercase transition-all duration-200 active:scale-95 flex items-center justify-center space-x-2 cursor-pointer"
            >
              <span>DOWNLOAD SPECIFICATION</span>
              <ChevronRight size={16} className="text-[#b0741a]" strokeWidth={2.5} />
            </button>
          </motion.div>

        </div>
      </main>
    </div>
  );
}
